/**
 * 
 */

$(document).ready(function(){


   $("#slToggle").click(function(){ $("#square").slideToggle(3000)});


});    